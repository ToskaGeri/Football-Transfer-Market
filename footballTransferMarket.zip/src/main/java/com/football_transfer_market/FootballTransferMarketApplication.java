package com.football_transfer_market;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballTransferMarketApplication {

    public static void main(String[] args) {
        SpringApplication.run(FootballTransferMarketApplication.class, args);
    }

}
